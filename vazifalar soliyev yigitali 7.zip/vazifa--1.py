n = [1,88,5,47,4,'58',8,4,"ok",8]
for i in n:
    if type(i)==int:
        a=n.index(i)
        n[a]=0
print(n)

