def name(a):
    x=list(a)
    return x
print(name("assalomu alaykum"))