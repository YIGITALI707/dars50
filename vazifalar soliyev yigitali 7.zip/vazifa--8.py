a=[1,2,3,4,6,8,11,21,22,33,12]
b=[]
for i in a:
    if i%2==0:
        b.append(i)
print(b)