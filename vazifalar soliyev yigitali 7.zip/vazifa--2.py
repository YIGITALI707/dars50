n = [1,88,5,47,4,'58',8,4,"ok",8 ]
q=[]
for i in n:
 if type(i)==int:
     q.append(i)
print(q)

