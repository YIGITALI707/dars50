def sum_range(a,b):
    x=list(range(a,b))
    return x
print(sum_range(12,25))