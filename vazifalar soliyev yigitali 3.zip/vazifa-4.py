x=input("satr yozing  ")
if len(x)<=10:
    print("satr to\'g\'ri kiritilgan")
else:
    print("satr notogri kiritilgan")