x=int(input("sonkiriting "))
y=int(input("2-sonni kiriting "))
if x<y:
    print(y)
else:
    print(x)