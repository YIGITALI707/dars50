x=input("soz kiriting:")
print(x.upper())