parol1=input("parolni kiriting ")
parol2=input("2-parolni kiriting ")
if parol1==parol2:
    print("parol1 parol2 ga mos ")
else:
    print("parol1 parol2 ga mos emas")