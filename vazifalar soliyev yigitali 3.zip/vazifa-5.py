x=input("soz kiriting:")
print(x.strip())
