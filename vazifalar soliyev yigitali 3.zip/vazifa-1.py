x=int(input("son kiriting "))
if x%2==0:
    print("juft son")
else:
    print("toq son")
