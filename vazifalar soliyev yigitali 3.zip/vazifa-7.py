x=int(input("son kiriting:"))
if len(str(x))==5:
    print("siz besh xonali son kiritdingiz")
else:
    print("siz besh xonali son kiritmadingiz")