import os
def tekshirish(yol):
    if os.path.exists(yol):
        print(f"{yol}=>>mavjud")
    else:
        print(f"{yol}=>>mavjud emas")
yol="C:\\Python\\2-Oy\\Lessons"
tekshirish(yol)
