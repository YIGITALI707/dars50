names=["John", "Alice", "Bob", "Alexander","Smith", "Doe"]
# def writer(file):
file=open('names.txt','w')
for i in names:
 file.write(i+" ")
# names=["John", "Alice", "Bob", "Alexander","Smith", "Doe"]
# writer(names)
#funkisayisin tuzolmadim shuni platformada qanday bo'lishiga izoh berib keting



