# import fayl2
# import fayl3
from fayl2 import x,million
from fayl3 import shark,summerize
print(dir())
print(million())
print(x)
print(shark())
print(summerize(1,6,4))
