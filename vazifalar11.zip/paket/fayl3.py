
def shark():
    print("file3@ dan olindi")


def summerize(*args):
    return sum(args)


