x=1998
def million():
    print("file2dan olindi")

