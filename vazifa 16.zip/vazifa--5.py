class Animal:
    def __init__(self,nomi,turi):
        self.nomi=nomi
        self.turi=turi
    def color(self):
        rangi=f"{self.nomi}:{self.turi}: sariq rangda"
        return rangi
    def age(self):
        yoshi=f"{self.nomi}:{self.turi}: sariq rangda va yoshi=3 da"
        return yoshi
a=Animal("KITTY","uy hayvoni")
print(a.age())
class Cat(Animal):
    def __init__(self,nomi,turi,egasi_ismi):
        super().__init__(nomi,turi)
        self.nomi = nomi
        self.turi = turi
        self.egasi_ismi=egasi_ismi
    def owner(self,egasi_ismi):
        ism=f"{self.nomi}:{self.turi}: qora rangda va yoshi=3 da.Egasining ismi {egasi_ismi}"
        return ism
x=Cat("REKS","uy hayvoni","John")
print(x.owner())





