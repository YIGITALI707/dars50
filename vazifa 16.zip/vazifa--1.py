class Dog:
    def __init__(self,name,age,color):
        self.name=name
        self.age=age
        self.color=color
    def __setattr__(self, name, value):
        if name=="name" and len(value)<3:
            return "ism uchta belgidan kam bo'lmasligi kerak"
        super().__setattr__(name,value)
dog=Dog("kitty",2,"white")
print(dog.name)