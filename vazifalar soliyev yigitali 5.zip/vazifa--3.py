fruits=["olma","nok","anor","behi","uzum"]
for x in range(1,6):
    x = input("meva nomini kiriting:")
    if x!=fruits:
        fruits.append(x)
        print(fruits)



        