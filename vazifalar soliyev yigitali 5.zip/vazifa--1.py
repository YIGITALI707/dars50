names=["olim","Li","John","Sardor","Alex"]
def count_a(names):
    summa=0
    for i in names:
     summa+=i.count("a")
    return summa
names=["olim","Li","John","Sardor","Alex"]
print(count_a(names))



