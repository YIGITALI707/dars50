fruits=["apple","banana","kiwi","mandarin"]
for i in range(1,5):
    x=input("meva kiriting:")
    if x in fruits:
     fruits.remove(x)
print(fruits)
