a=int(input("son kiriting  "))

b=int(input("son kiriting  "))

c=int(input("son kiriting  "))
print(a+b+c)
