x=input("# bilan soz kiriting:")
symbol="#"
y=x.replace(symbol,"")
print(y)