x=int(input("Tugilgan yilingizni kiriting:"))
print("sizni yoshingiz ",2024-x," ga teng")