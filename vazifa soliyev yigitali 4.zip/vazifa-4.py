# sum1=0
# x=input("satr yozing")
# for i in range(len(x)):
#     if x.isalpha()==True:
#         sum1+=len(x)
# print(sum)
s="qwertyuiopasdfghjklzxcvbnm"
x=input("satr kiriting")
sum1=0
for i in range(len(x)-1):
        if x[len(x)-1]==s[len(s)-1]:
         print(x)
