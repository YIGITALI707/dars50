i=0
summa=0
while i==0 :
    x = int(input("son kiriting, agar son kiritib zeriksangiz 0 ni 3 marta  kiriting "))
    if x==000:
        break
    summa+=x
    print(summa)
