a = [88,44,12,36,95,77,88,44,12,36]
def del_duplicate(a):
    x=set(a)
    return x
print(del_duplicate(a))