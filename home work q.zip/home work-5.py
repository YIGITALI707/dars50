a = {1,2,3,4,5,6}
b = {1,2,9,8,10}
print(a.symmetric_difference(b))