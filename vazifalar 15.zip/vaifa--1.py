class Rect:
    a=4 
    b=3
    def __init__(self,a,b):
        self.a=a
        self.b=b
    def area(self):
        return self.a*self.b
tortburchak=Rect(4,3)
print(tortburchak.area())

