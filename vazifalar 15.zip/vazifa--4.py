class FileReader:
    def __init__(self,file_name):
        self.file_name=file_name
    def reader(self):
        try:
            f=open(self.file_name,"r")
            x=f.read()
            print(x,"fayl topildi")
        except BaseException:
            print("fayl topilmadi")
fayl=FileReader("parollar.txt")
print(fayl.reader())





