class Phone:
    color="silver"
    model="RedMi not 12 PRO+ 5G"
    price=45000000
    def __init__(self,color,model,price):
        self.model=model
        self.price=price
        self.color=color
telefon=Phone(color="silver",model="RedMi not 12 PRO+ 5G",price=45000000)
print(telefon.__dict__)