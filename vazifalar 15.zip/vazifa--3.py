class ListSort:
    def __init__(self,obj_list):
        self.obj_list=obj_list
    def even_numbers(self):
       for i in self.obj_list:
           if i%2==0:
            return i
saralangan=ListSort([1,2,3,4,5,6,7,8,9,10,11,12,13,14])
print(saralangan.even_numbers())
#shu yerda qayerda xato qilganimni platformaga izoh bilan tushuntirvoring
#oxirida faqat bitta javobni chiqaryapti hamma listdagi juft sonlarni olmayapti

