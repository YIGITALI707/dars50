import json
x=open("data.json","r")
data=json.load(x)
print(data)