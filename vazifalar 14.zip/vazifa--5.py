x=["list ichidagi","fayllarni","index.txt","faylga yozuvchi dastur tuzing"]
file=open("index.txt","w")
for i in x:
    file.write(i+" ")
print("muvaffaqqiyatli bajarildi")