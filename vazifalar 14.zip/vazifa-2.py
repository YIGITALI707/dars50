x=input("Ma'lumot kiriting:")
try:
    y=int(x)
    print(f"{y} ma'lumot int ga aylantirildi")
except BaseException:
    print("siz butun son kiritmadingiz")