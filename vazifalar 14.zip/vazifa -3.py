import json
data={"Tovar nomi":" ","Tovar narxi":000,"Tovar soni":0}
for i in range(1):
    x=input("Tovar nomi:")
    y=int(input("Tovar narxi:"))
    z=int(input("Tovar soni:"))
    data["Tovar nomi"]=x
    data["Tovar narxi"]=y
    data["Tovar soni"]=z
    f=open("data.json","w")
    json.dump(data,f,indent=4)






