sanalgan_fayllar=0
while sanalgan_fayllar<10:
   file=open(f"open{sanalgan_fayllar+1}.txt","w")
   file.write("fayllar")
   sanalgan_fayllar+=1


