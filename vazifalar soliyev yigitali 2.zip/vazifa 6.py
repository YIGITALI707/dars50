n=int(input("N ni qiymatini kiriting "))
k=int(input("K ni qiymatini kiriting "))
print("har bir talaba ",n//k," dan niqob olishadi")