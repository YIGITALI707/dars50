a="Google"
b="eng"
c="xisoblanadi"
message=f"{a} dunyodagi {b} katta kompaniyalardan {c}"
print(message)