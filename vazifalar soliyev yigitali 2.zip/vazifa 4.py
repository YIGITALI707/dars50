a=int(input("Son kiriting "))
if a<100:
    print("xa")
else:
    print("yo\'q")