a=int(input("a ni qiymatini kiriting "))
b=int(input("b ni qiymatini kiriting "))
c=int(input("c ni qiymatini kiriting "))
print((a+b)*c)