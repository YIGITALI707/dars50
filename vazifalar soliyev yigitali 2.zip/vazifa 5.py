a=int(input("son kiriting "))
b=int(input("2-sonni kiriting "))
if a<b:
    print("a soni b dan kichik")
else:
    print("b soni a dan kichik")